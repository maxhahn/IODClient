logiquant.regs <- function(target, dataset, logged = FALSE) {
  Rfast2::logiquant.regs(target, dataset, logged = logged)
}
  
